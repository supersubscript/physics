public abstract class Ant
{

}
