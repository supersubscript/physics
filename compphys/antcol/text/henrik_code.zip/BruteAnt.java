public class BruteAnt extends Ant
{
   static final int INDEX = 1; // index for keeping track of the ant races
   static final int STR = 10;
   static final int SPEED = 2;
}
