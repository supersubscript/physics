import java.util.ArrayList;

public class SpeedAnt extends Ant
{
   static final int INDEX = 0; // index for keeping track of the ant races
   static final int STR = 1;
   static final int SPEED = 10;
}
